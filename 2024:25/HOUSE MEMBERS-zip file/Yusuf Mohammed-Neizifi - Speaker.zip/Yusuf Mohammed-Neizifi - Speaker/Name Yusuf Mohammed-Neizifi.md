Name: Yusuf Mohammed-Neizifi  
Current Position: Speaker of the House  
Level: 600L  
I am a final-year medical student passionate about creating a more equitable and sustainable healthcare system. I aspire to be a strong advocate for affordable and accessible medical care for everyone, especially in underserved communities. I am driven by a desire to make lasting, change in the way healthcare is practiced and experienced.  
  
  
  
![Image](Attachments/IMG_2162.jpeg)  
